import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;


public class RMIInterfaceImpl extends UnicastRemoteObject implements RMIInterface {
	
	private static final long serialVersionUID = 1L;
	public RMIInterfaceImpl() throws RemoteException{
}
	
	public int  SqaurePerimeter(int width, int length){
		int  result;
		result =  2*(width+length);
		return result;
	}


	public double Circle3DArea(int radius) throws RemoteException {
		// TODO Auto-generated method stub
		double result = Math.PI*radius*radius;
		return result;
	}


	public double TriangleArea(int base, int height) throws RemoteException {
		 double result = 0.5*(base+height);   
		 return result;
	}
	

}
