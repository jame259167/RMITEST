package testRMI;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

public class RMIServer implements RMIInterface {
	
	

	public String remoteMethod() {
		return "Remote Method in RMIServer called !!";
	}
	
	public static void main(String args[]) {
	try {
		RMIServer remoteObj = new RMIServer();
		RMIInterface stub = (RMIInterface) UnicastRemoteObject.exportObject(remoteObj, 0);

		Registry registry = LocateRegistry.getRegistry();
		registry.bind("RMIInterface", stub);

		System.err.println("Server start ....");
	} catch (Exception e) {
		System.err.println("Exception occur : " + e.toString());
	}
}

	public int  SqaurePerimeter(int width, int length){
		int  result;
		result =  2*(width+length);
		return result;
	}


	public double Circle3DArea(int radius) throws RemoteException {
		// TODO Auto-generated method stub
		double result = Math.PI*radius*radius;
		return result;
	}


	
	public double TriangleArea(int base, int height) throws RemoteException {
		 double result = 0.5*(base+height);   
		 return result;
	}
	
}
