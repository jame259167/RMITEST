package testRMI;

import java.rmi.Naming;

public class RMIClient {

	public static void main(String[] args) {
		try{
			RMIInterface obj = (RMIInterface)Naming.lookup("//localhost:1099/RMIServer");			
			int perimeterS1 = obj.SqaurePerimeter(Integer.parseInt(args[0]), Integer.parseInt(args[1]));
			double areaC1 = obj.Circle3DArea(Integer.parseInt(args[2]));
			double areaT1 = obj.TriangleArea(Integer.parseInt(args[3]), Integer.parseInt(args[4]));
			
			System.out.println("Perimeter Square width = "+args[0]+" height = "+args[1]+" is "+perimeterS1);
			System.out.println("Area of Circle radius = "+args[2]+" is "+areaC1);
			System.out.println("Area of Triangle width = "+args[3]+" height = "+args[4]+" is "+areaT1);
		}catch(Exception e){
			System.out.println("Have Error!!!");		
		}
	
	}
}