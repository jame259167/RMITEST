package testRMI;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface RMIInterface extends Remote {
	public int SqaurePerimeter (int x,int y) throws RemoteException;
	public double Circle3DArea    (int x) throws RemoteException;
	public double TriangleArea    (int x,int y) throws RemoteException;
}
